package com.example.denemeactivity;

public class Model {
    String url;

    public Model() {
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
