package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private ListView numberListView, cityListView;
    private ArrayAdapter<Integer> numberAdapter;
    private ArrayAdapter<String> cityAdapter;
    private List<Integer> numbers = new ArrayList<>();
    private List<String> cities = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // ListView'ları tanımla
        numberListView = findViewById(R.id.numberListView);
        cityListView = findViewById(R.id.cityListView);

        // Şehirleri ve plakaları ListView'a ekle
        cities.add("İstanbul - 34");
        cities.add("Ankara - 06");
        cities.add("İzmir - 35");
        cities.add("Bursa - 16");
        cities.add("Antalya - 07");
        cities.add("Adana - 01");
        cities.add("Trabzon - 61");
        cities.add("Eskişehir - 26");
        cities.add("Gaziantep - 27");
        cities.add("Konya - 42");
        cityAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, cities);
        cityListView.setAdapter(cityAdapter);

        // ListView'ların tıklanma olaylarını dinle
        numberListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Seçilen numarayı al
                int selectedNumber = numbers.get(position);

                // İkinci ekrana geç ve seçilen numarayı gönder
                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                intent.putExtra("selectedNumber", selectedNumber);
                startActivity(intent);
            }
        });

        cityListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Seçilen şehri ve plakayı al
                String selectedCity = cities.get(position);

                // Şehir ve plakayı ayrıştır
                String[] parts = selectedCity.split(" - ");
                String cityName = parts[0];
                String plateNumber = parts[1];

                // İkinci ekrana geç ve seçilen şehri ve plakayı gönder
                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                intent.putExtra("cityName", cityName);
                intent.putExtra("plateNumber", plateNumber);
                startActivity(intent);
            }
        });

        // Butona tıklama olayını ekle
        Button generateButton = findViewById(R.id.generateButton);
        generateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Random sayıları oluştur ve ListView'a ekle
                Random random = new Random();
                numbers.clear(); // Önceki sayıları temizle
                for (int i = 0; i < 10; i++) {
                    int number = random.nextInt(81) + 1;
                    numbers.add(number);
                }
                if (numberAdapter == null) {
                    numberAdapter = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_list_item_1, numbers);
                    numberListView.setAdapter(numberAdapter);
                } else {
                    numberAdapter.notifyDataSetChanged(); // Adapter'ı güncelle
                }
            }
        });
    }
}