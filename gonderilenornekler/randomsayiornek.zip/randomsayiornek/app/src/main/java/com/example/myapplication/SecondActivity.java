package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        TextView resultTextView = findViewById(R.id.resultTextView);

        Intent intent = getIntent();
        if (intent.hasExtra("selectedNumber")) {
            int selectedNumber = intent.getIntExtra("selectedNumber", 0);
            if (selectedNumber >= 1 && selectedNumber <= 81) {
                resultTextView.setText("Eşleşti!");
            } else {
                resultTextView.setText("Eşleşmedi!");
            }
        } else if (intent.hasExtra("cityName") && intent.hasExtra("plateNumber")) {
            String cityName = intent.getStringExtra("cityName");
            String plateNumber = intent.getStringExtra("plateNumber");
            if (cityName.equals("İstanbul") && plateNumber.equals("34")) {
                resultTextView.setText("Eşleşti!");
            } else {
                resultTextView.setText("Eşleşmedi!");
            }
        }
    }
}